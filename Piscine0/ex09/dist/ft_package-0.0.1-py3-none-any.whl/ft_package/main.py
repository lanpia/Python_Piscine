def count_in_list(items, target):
    """
Returns the count of a specific element (target) in a given list.
    """
    return items.count(target)
