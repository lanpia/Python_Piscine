# ft_package

A sample test package for counting items in a list.

## Usage
```python
from ft_package import count_in_list

print(count_in_list(["toto", "tata", "toto"], "toto"))  # 출력: 2
print(count_in_list(["toto", "tata", "toto"], "tutu"))  # 출력: 0
```
